// Cloudflare Pages Function: POST /api/order
// Secrets in Cloudflare Pages -> Settings -> Variables and Secrets:
// TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID
const allowedCountries = new Set(['Dubay','Maldiv orollari','Bali','Sharm ash-Shayx','Yaponiya','Italiya','Boshqa yo‘nalish']);
const allowedGuests = new Set(['1 kishi','2 kishi','3 kishi','4 kishi','5+ kishi']);
const allowedBudgets = new Set(['Kelishiladi','$500–$1 000','$1 000–$2 000','$2 000–$5 000','$5 000+']);
const json = (body, status = 200) => new Response(JSON.stringify(body), {status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
const str = (value,max) => typeof value === 'string' ? value.trim().slice(0,max) : '';
export async function onRequestPost({request,env}) {
  if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return json({ok:false,error:'Telegram bot hali sozlanmagan. Sayt egasiga murojaat qiling.'},503);
  if (!request.headers.get('content-type')?.toLowerCase().includes('application/json')) return json({ok:false,error:'Noto‘g‘ri so‘rov.'},415);
  if (Number(request.headers.get('content-length')||'0') > 12000) return json({ok:false,error:'So‘rov hajmi juda katta.'},413);
  let data;
  try {data=await request.json();}catch{return json({ok:false,error:'So‘rov ma’lumotlari noto‘g‘ri.'},400);}
  if (data.website) return json({ok:true}); // Honeypot
  const name=str(data.name,80), phone=str(data.phone,30), country=str(data.country,50);
  const date=str(data.date,12), guests=str(data.guests,12), budget=str(data.budget,24), note=str(data.note,500);
  if (!data.consent || name.length<2 || !/^[+\d()\s-]{9,30}$/.test(phone) || !allowedCountries.has(country) || !allowedGuests.has(guests) || !allowedBudgets.has(budget) || (date && !/^\d{4}-\d{2}-\d{2}$/.test(date))) {
    return json({ok:false,error:'Ma’lumotlarni tekshirib, qayta urinib ko‘ring.'},400);
  }
  const message = [
    '✈️ JAVOHIR_RICH — YANGI TUR SO‘ROVI',
    '👤 Ism: '+name,
    '📞 Telefon: '+phone,
    '🌍 Yo‘nalish: '+country,
    '📅 Sana: '+(date||'Kelishiladi'),
    '👥 Sayohatchilar: '+guests,
    '💰 Budjet: '+budget,
    '📝 Izoh: '+(note||'—'),
    '🕒 Qabul qilindi: '+new Date().toISOString()
  ].join('\n');
  try {
    const tg = await fetch('https://api.telegram.org/bot'+env.TELEGRAM_BOT_TOKEN+'/sendMessage', {
      method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify({chat_id:env.TELEGRAM_CHAT_ID,text:message,disable_web_page_preview:true}),
      signal:AbortSignal.timeout(10000)
    });
    const result = await tg.json();
    if (!tg.ok || !result.ok) {
      console.error('Telegram delivery failed',tg.status,result.error_code);
      return json({ok:false,error:'Telegramga yuborish amalga oshmadi. Iltimos, bizga bevosita yozing.'},502);
    }
    return json({ok:true});
  } catch (e) {
    console.error('Telegram connection failed',e?.name);
    return json({ok:false,error:'Hozircha xabarni yetkazib bo‘lmadi. Iltimos, qayta urinib ko‘ring.'},502);
  }
}
export function onRequestGet(){return json({ok:false,error:'Bu manzil faqat buyurtma yuborish uchun.'},405);}
